function generateRandomString(length) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  }

context('TC005', () => {
    beforeEach(() => {
      cy.visit('http://tech-avito-intern.jumpingcrab.com/')
    })  
    
    it('.type() - generate random string', () => {
        const randomString = generateRandomString(10);
        cy.viewport(1920, 1080)
        cy.contains('Создать').click()
        cy.get('input[name="name"]').type(randomString);
        cy.get('input[name="price"]').type('20')
        cy.get('label#field-\\:rp\\:-label').type('Описание тестового объявления')
        cy.get('input[name="imageUrl"]').type('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRT7BBe-HRJ0YJEyFwtmu3m4yMCKHzvKVandw&s')
        cy.contains('Сохранить').click()
        cy.get('input[placeholder="Поиск по объявлениям"]').type(randomString)
        cy.contains(randomString).click()
        cy.get('path[d="M402.3 344.9l32-32c5-5 13.7-1.5 13.7 5.7V464c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V112c0-26.5 21.5-48 48-48h273.5c7.1 0 10.7 8.6 5.7 13.7l-32 32c-1.5 1.5-3.5 2.3-5.7 2.3H48v352h352V350.5c0-2.1.8-4.1 2.3-5.6zm156.6-201.8L296.3 405.7l-90.4 10c-26.2 2.9-48.5-19.2-45.6-45.6l10-90.4L432.9 17.1c22.9-22.9 59.9-22.9 82.7 0l43.2 43.2c22.9 22.9 22.9 60 .1 82.8zM460.1 174L402 115.9 216.2 301.8l-7.3 65.3 65.3-7.3L460.1 174zm64.8-79.7l-43.2-43.2c-4.1-4.1-10.8-4.1-14.8 0L436 82l58.1 58.1 30.9-30.9c4-4.2 4-10.8-.1-14.9z"]').click()
        cy.get('input[name="name"]').clear().type('тест2')
        cy.get('input[name="price"]').clear().type('-30')
        cy.get('textarea[name="description"]').clear().type('Описание отредактированное')
        cy.get('input[name="imageUrl"]').clear().type('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQp4NN7qm7PdNxZduX18Dyu36XaOdh7me2GSA&s')
        cy.get('svg[stroke="currentColor"][fill="currentColor"][viewBox="0 0 24 24"]').click()
        })
})