context('TC009_TC010', () => {
    beforeEach(() => {
        cy.visit('http://tech-avito-intern.jumpingcrab.com/')
    })

    it('.type()', () => {
        cy.viewport(1920, 1080)
        cy.get('button#menu-button-\\:rc\\:').click()
        cy.contains('Цена').click()
        cy.contains('Items on page').click()
        cy.contains('25').click()
        cy.get('button#menu-button-\\:rh\\:').click()
        cy.contains('По возрастанию').click({force: true})
        cy.wait(5000)
        cy.get('button#menu-button-\\:rh\\:').click()
        cy.contains('По убыванию').click({force: true})
        

    })
})