import './TC-001.cy';
import './TC-002.cy';
import './TC-003.cy';
import './TC-004.cy';
import './TC-005.cy';
import './TC-006.cy';
import './TC-007.cy';
import './TC-008.cy';
import './TC-009_TC-010.cy';

describe('Запуск всех тестов Avito по порядку', () => {
    it('Запуск тестов', () => {
      cy.log('Все тесты из списка импортированы и выполняются по очереди.');
    });
  });
