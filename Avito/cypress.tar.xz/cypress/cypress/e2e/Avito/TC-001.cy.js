context('TC001', () => {
    beforeEach(() => {
      cy.visit('http://tech-avito-intern.jumpingcrab.com/')
    })  
    
    it('.type()', () => {
        cy.viewport(1920, 1080)
        cy.contains('Создать').click()
        cy.get('input[name="name"]').type('тестовое объявление 1')
        cy.get('input[name="price"]').type('20')
        cy.get('label#field-\\:rp\\:-label').type('Описание тестового объявления')
        cy.get('input[name="imageUrl"]').type('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRT7BBe-HRJ0YJEyFwtmu3m4yMCKHzvKVandw&s')
        cy.contains('Сохранить').click()
        cy.get('input[placeholder="Поиск по объявлениям"]').type('Тестовое')
        cy.contains('Найти').click()

        })
})