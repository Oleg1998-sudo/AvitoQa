context('TC008', () => {
    beforeEach(() => {
        cy.visit('http://tech-avito-intern.jumpingcrab.com/')
    })

    it('.type()', () => {
        cy.viewport(1920, 1080)
        cy.get('button#menu-button-\\:rc\\:').click()
        cy.contains('Цена').click()
    })
})