context('TC003', () => {
    beforeEach(() => {
      cy.visit('http://tech-avito-intern.jumpingcrab.com/')
    })  
    
    it('.type()', () => {
        cy.viewport(1920, 1080)
        cy.contains('Создать').click()
        cy.get('input[name="name"]').type('тестовое объявление')
        cy.get('input[name="price"]').type('10')
        cy.get('label#field-\\:rp\\:-label').type('Описание тестового объявления')
        cy.get('input[name="imageUrl"]').type('картинка')
        cy.contains('Сохранить').click()

        })
})