context('TC006', () => {
    beforeEach(() => {
      cy.visit('http://tech-avito-intern.jumpingcrab.com/')
    })  
    
    it('.type()', () => {
        cy.viewport(1920, 1080)
        cy.get('input[placeholder="Поиск по объявлениям"]').type('Диван')
        cy.contains('Найти').click()
        })
})