function generateRandomString(length) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  }

context('TC007', () => {
    beforeEach(() => {
      cy.visit('http://tech-avito-intern.jumpingcrab.com/')
    })  
    
    it('.type() - generate random string', () => {
        const randomString = generateRandomString(10);
        cy.viewport(1920, 1080)
        cy.get('input[placeholder="Поиск по объявлениям"]').type(randomString)
        cy.contains('Найти').click()
        })
})